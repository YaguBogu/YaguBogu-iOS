import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    var appCoordinator: AppCoordinator?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        let nav = UINavigationController()
        appCoordinator = AppCoordinator(navigationController: nav)
        appCoordinator?.start()

        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = nav
        window.makeKeyAndVisible()

        self.window = window
        
        
        //배포시 제거
        CoreDataStack.shared.addDummyData()
    }
}

