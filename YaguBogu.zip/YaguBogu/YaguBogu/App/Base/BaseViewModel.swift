//
//  BaseViewModel.swift
//  YaguBogu
//
//  Created by oww on 11/18/25.
//

import Foundation
