
import Foundation
import CoreData

@objc(RecordData)
public class RecordData: NSManagedObject {

}
