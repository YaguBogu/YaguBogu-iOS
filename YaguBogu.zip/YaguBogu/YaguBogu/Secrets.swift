import ConfidentialKit

enum Secrets {

    static #Obfuscate {
        let BaseballApiKey = "ff42f54fc347de081af9dd02c0773594"
        let WeatherApiKey = "2dafcfcea7942ab35fd40ac0d151fe89"
        
    }
}
